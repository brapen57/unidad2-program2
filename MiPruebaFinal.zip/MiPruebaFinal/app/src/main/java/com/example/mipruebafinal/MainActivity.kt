package com.example.mipruebafinal

import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.FileNotFoundException
import java.io.ObjectInputStream
import java.io.ObjectOutputStream
import java.io.Serializable


class MainActivity : ComponentActivity() {
    private val shoppingListViewModel: ShoppingListViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        loadShoppingListFromFile()

        setContent {

            AppNavigation(shoppingListViewModel)
        }
    }

    override fun onPause() {
        super.onPause()

        saveShoppingListToFile()
    }

    override fun onStop() {
        super.onStop()

        saveShoppingListToFile()
    }

    private fun saveShoppingListToFile() {

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                ObjectOutputStream(openFileOutput("shopping_list.dat", Context.MODE_PRIVATE)).use { stream ->
                    stream.writeObject(shoppingListViewModel.shoppingList.value)
                }
            } catch (e: Exception) {
                Log.e("MainActivity", "Error saving shopping list to file", e)
            }
        }
    }

    private fun loadShoppingListFromFile() {

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                ObjectInputStream(openFileInput("shopping_list.dat")).use { stream ->
                    @Suppress("UNCHECKED_CAST")
                    val loadedShoppingList = stream.readObject() as List<ShoppingListItemState>


                    shoppingListViewModel.updateShoppingList(loadedShoppingList)
                }
            } catch (e: FileNotFoundException) {

            } catch (e: Exception) {
                Log.e("MainActivity", "Error loading shopping list from file", e)
            }
        }
    }
}

@Composable
fun AppNavigation(shoppingListViewModel: ShoppingListViewModel)
{
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "ShoppingListWithLogo"
    ) {
        composable("ShoppingListWithLogo") {
            PageShoppingListWithLogoUI (
                viewModel = shoppingListViewModel,
                onClick = {
                    navController.navigate("Configuracion")
                }
                )
            }

        composable("Configuracion") {
            PageConfiguracionUI(
                navController = navController
                )
        }
    }
}

@Composable
fun PageShoppingListWithLogoUI(
    viewModel: ShoppingListViewModel = viewModel(),
    onClick: () -> Unit
) {

    val contexto = LocalContext.current
    val shoppingList by viewModel.shoppingList.collectAsState()
    val focusRequester = remember { FocusRequester() }
    var newProduct by remember { mutableStateOf("") }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .background(MaterialTheme.colorScheme.background)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.ShoppingCart,
                contentDescription = "Shopping Cart",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(36.dp)
            )
            Text(
                text = contexto.getString(R.string.shopping_list_title),
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = contexto.getString(R.string.button_next),
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .size(56.dp)
                    .clickable {
                        onClick()
                    }
            )
        }

        OutlinedTextField(
            value = newProduct,
            onValueChange = { value ->
                newProduct = value
            },
            label = { Text(contexto.getString(R.string.new_product)) },
            keyboardOptions = KeyboardOptions.Default.copy(
                imeAction = ImeAction.Next
            ),
            keyboardActions = KeyboardActions(
                onDone = {
                    Log.d("PageShoppingListWithLogoUI", "Botón Hecho presionado")
                    viewModel.addItem(newProduct)

                    newProduct = ""
                    focusRequester.freeFocus()
                }
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
                .background(Color.White)
        )
        Button(
            onClick = {
                try {

                    viewModel.addItem(newProduct)
                    newProduct = ""
                    focusRequester.freeFocus()
                } catch (e: Exception) {
                    Log.e("PageShoppingListWithLogoUI", "Error al agregar producto", e)

                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Text("Agregar Producto")
        }


        shoppingList.forEachIndexed { index, item ->
            ShoppingListItem(
                item = item,
                onCheckedChange = { isChecked ->
                    viewModel.markProductAsFound(item, isChecked)
                },
                onDeleteClicked = {
                    viewModel.removeItem(index)
                }
            )
        }
    }
}






@Composable
fun PageConfiguracionUI(
    navController: NavController,
    viewModel: ConfiguracionViewModel = viewModel()
) {
    val contexto = LocalContext.current


    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector =  Icons.Default.ArrowForward,
                contentDescription = contexto.getString(R.string.button_back),
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .size(36.dp)
                    .clickable {
                        navController.popBackStack()
                    }
            )
            Text(
                text = contexto.getString(R.string.title_configuration),
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.primary
            )
        }


        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { /* Handle sorting action */ }
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Switch(
                checked = viewModel.ordenAlfabetico.value,
                onCheckedChange = { isChecked ->
                    viewModel.setOrdenAlfabetico(isChecked)
                }
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = contexto.getString(R.string.button_sort),
                style = MaterialTheme.typography.bodyMedium
            )
        }


        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {  }
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Switch(
                checked = viewModel.mostrarNoEncontrados.value,
                onCheckedChange = { isChecked ->
                    viewModel.setMostrarNoEncontrados(isChecked)

                }
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = contexto.getString(R.string.button_show_unfound),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun ShoppingListItem(
    item: ShoppingListItemState,
    onCheckedChange: (Boolean) -> Unit,
    onDeleteClicked: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = item.isChecked,
            onCheckedChange = { isChecked ->
                onCheckedChange(isChecked)
            },
            colors = CheckboxDefaults.colors(
                checkmarkColor = MaterialTheme.colorScheme.primary
            )
        )

        Text(
            text = item.name,
            style = if (item.isChecked) {
                TextStyle(
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Normal,
                    lineHeight = 24.sp,
                    letterSpacing = 0.sp,
                    color = Color.Gray,
                    textDecoration = TextDecoration.LineThrough
                )
            } else {
                TextStyle(
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Normal,
                    lineHeight = 24.sp,
                    letterSpacing = 0.sp,
                    color = Color.Blue,
                    textDecoration = TextDecoration.None
                )
            },
            modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp)
        )

        Icon(
            imageVector = Icons.Default.Delete,
            contentDescription = "Delete",
            tint = Color.Gray,
            modifier = Modifier
                .size(24.dp)
                .clickable {
                    onDeleteClicked()
                }
        )
    }
}

data class ShoppingListItemState(val name: String, val isChecked: Boolean = false) : Serializable

@Preview(showSystemUi = true)
@Composable
fun PageShoppingListWithLogoUIPreview() {
    val shoppingListViewModel = ShoppingListViewModel()

    PageShoppingListWithLogoUI(shoppingListViewModel) {  }
}

@Preview(showSystemUi = true)
@Composable
fun PageConfiguracionUIPreview() {
    PageConfiguracionUI(
        navController = rememberNavController()
    )
}