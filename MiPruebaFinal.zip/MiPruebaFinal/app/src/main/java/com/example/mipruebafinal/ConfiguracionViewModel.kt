package com.example.mipruebafinal


import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel

class ConfiguracionViewModel : ViewModel() {

    private val _ordenAlfabetico = mutableStateOf(false)
    val ordenAlfabetico: MutableState<Boolean> = mutableStateOf(false)
    private val _mostrarNoEncontrados = mutableStateOf(false)

    val mostrarNoEncontrados: MutableState<Boolean> = mutableStateOf(false)
    fun setOrdenAlfabetico(ordenAlfabetico: Boolean) {
        _ordenAlfabetico.value = ordenAlfabetico

    }

    fun setMostrarNoEncontrados(mostrar: Boolean) {
        _mostrarNoEncontrados.value = mostrar

    }


}