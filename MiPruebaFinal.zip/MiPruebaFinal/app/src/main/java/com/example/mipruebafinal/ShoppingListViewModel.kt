package com.example.mipruebafinal

import android.util.Log
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow

class ShoppingListViewModel : ViewModel() {
    private val _shoppingList = MutableStateFlow(
        listOf(
            ShoppingListItemState("Manzanas"),
            ShoppingListItemState("Plátanos"),
            ShoppingListItemState("Leche"),
            ShoppingListItemState("Pan")
        )
    )

    val shoppingList: MutableStateFlow<List<ShoppingListItemState>> = _shoppingList

    fun addItem(newProduct: String) {
        Log.d("ShoppingListViewModel", "Añadiendo producto: newProduct")
        val updatedList = _shoppingList.value.toMutableList().apply {
            add(ShoppingListItemState(newProduct))
        }
        _shoppingList.value = updatedList
    }

    fun markProductAsFound(product: ShoppingListItemState, isFound: Boolean) {
        val updatedList = _shoppingList.value.toMutableList().apply {
            val index = indexOf(product)
            if (index != -1) {
                this[index] = product.copy(isChecked = isFound)
            }
        }
        _shoppingList.value = updatedList
    }

    fun removeItem(index: Int) {
        val updatedList = _shoppingList.value.toMutableList().apply {
            removeAt(index)
        }
        _shoppingList.value = updatedList
    }

    fun sortShoppingList() {
        val sortedList = _shoppingList.value.toMutableList().apply {
            sortBy { it.name }
        }
        _shoppingList.value = sortedList
    }
    fun updateShoppingList(newList: List<ShoppingListItemState>) {
        _shoppingList.value = newList
    }
}




